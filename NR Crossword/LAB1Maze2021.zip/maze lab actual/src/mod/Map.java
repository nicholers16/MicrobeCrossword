package mod;

public enum Map {
	//level r:18 c: 15
	//easy start loc (0,0). end loc (17,14). trap1 (7,1) trap2 (8,14). min1 (10,1) min2 (8,4) min3 ( 11,12
	//add these characteristics to maze
	Easy(new boolean[][] {
			{ true, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
			{ true, false, true, false, true, true, true, false, false, true, false, false, true, true, false},
			{ true,  true,  true,  true, true, false, true, false, false, true, true, true, false, true, false},
			{ false, true, false, true, false, false, true, true, false, true, true, true, false, true, false},
			{ false, true, false, true, false, false, false, true, true, true, false, true, true, true, false},
			{ false, true, true, true, false, false, false, false, false, true, false, true, true, false, false},
			{ false, true, 	false,  true,  true,  true,  true,  true,  true, true, false, true, true, false, false},
			{ false, true, false, false, false, false, false, false, false, true, false, false, true, false, false},
			{ false, true, true, false, true, false, true, false, false, true, false, true, true, false, false},
			{ false, true, false, false, false, true, true, true, false, true, true, true, true, true, false},
			{ true,  true,  true,  true, false, true, false, true, true, true, false, false, true, false, false},
			{ false, false, false, true, false, true, false, true, false, true, false, false, true, true, false},
			{ false, false, false, true, true, true, false, true, false, true, false, false, false, true, false},
			{ false, false, false, true, false, false, false, false, false, true, false, false, false, true, false},
			{ false, true, 	true,  true,  true,  true,  true,  true, true, true, true, true, false, false, false},
			{ false, true, false, false, false, false, false, false, false, false, false, true, true, true, false},
			{ false, true, false, false, false, false, false, false, false, false, false, false, false, true, false},
			{ false, true, false, false, false, false, false, false, false, false, false, false, false, true, true}
	}), // semi-colon ends the number of variables!!!
	//medium start loc (0,6) end loc (17,7). min1 (4,1) min2 (11,12) min3(16,11). trap1 (3,5) trap2 (4,1) trap3(6,2)
	Medium (new boolean[][] {
			{ false, false, false, false, false, false, true, false, false, false, false, false, false, false, false},
			{ false, true, false, false, true, true, true, false, false, true, true, true, true, false, false},
			{ false,  true,  true,  true, true, false, true, false, false, false, true, false, true, false, false},
			{ false, true, false, true, true, true, true, true, true, true, true, false, true, false, false},
			{ false, true, false, true, false, false, false, true, false, true, false, true, true, false, false},
			{ false, false, false, true, false, false, false, true, false, true, false, false, true, true, false},
			{ false, true, 	true,  true,  true,  true,  true,  true, true, true, false, false, false, true, false},
			{ false, true, false, false, false, false, false, true, false, true, true, true, true, true, false},
			{ false, true, false, false, false, true, true, true, true, true, false, false, true, false, false},
			{ false, true, false, false, true, true, false, false, false, false, false, true, true, false, false},
			{ true,  true,  true,  true, true, true, true, true, true, true, false, false, true, false, false},
			{ false, false, false, true, true, false, true, false, false, true, false, true, true, false, false},
			{ false, false, false, true, true, true, true, false, false, true, true, true, true, true, false},
			{ false, false, false, true, false, false, true, false, false, false, false, true, false, true, false},
			{ false, true, 	true,  true,  true,  false,  true,  true,  true, true, false, true, false, true, false},
			{ false, true, false, true, false, false, true, false, false, false, false, true, false, true, false},
			{ false, true, false, true, true, false, true, true, false, false, false, true, false, true, false},
			{ false, true, false, false, false, false, false, true, false, false, false, false, false, true, false}
	}),

	//hard start loc (0,0) end loc (17,1). min1 (6,1) min2(6,9) min3(10,13) trap1(2,3) trap2(14,4) trap3(10,10) sword (1,0)
	Hard(new boolean[][] {
			{ true, false, false, false, false, false, false, false, false, true, false, false, false, false, false},
			{ true, false, false, true, true, true, false, false, false, true, false, true, true, false, false},
			{ true,  true,  true,  true, false, true, false, true, false, true, false, false, true, true, false},
			{ false, true, false, true, false, true, false, true, false, true, false, false, true, false, false},
			{ false, true, false, true, false, true, true, true, true, true, true, true, true, true, false},
			{ false, false, false, true, false, false, false, false, true, false, true, false, true, false, false},
			{ false, true, true,  true,  true, false, true, true, true, true, true, false, true, false, false},
			{ false, false, true, false, true, true, true, false, false, false, false, true, false, false, false},
			{ false, false, true, false, false, true, true, false, false, false, false, true, true, true, false},
			{ false, false, true, false, false, false, false, false, false, false, false, true, false, true, false},
			{ false,  false,true, false, false, false, false, false, false, true, true, true, false, true, false},
			{ false, false, true, true, false, false, false, false, false, true, false, false, false, true, false},
			{ false, false, false, true, false, false, false, false, false, true, false, false, false, true, false},
			{ false, false, false, true, false, false, false, false, false, true, false, true, true, true, false},
			{ false, true, 	false,  true,  true,  true,  true,  true,  true, true, false, true, false, false, false},
			{ false, true, false, true, false, false, false, false, false, false, true, true, false, false, false},
			{ false, true, true, true, true, true, true, true, true, true, true, false, false, false, false},
			{ false, true, false, false, false, false, false, false, false, false, false, false, false, false, false}
	});
	
	private boolean[][] _map;

	public boolean[][] getArr() {
		return _map;
	}

	private Map(boolean[][] map) {
		_map = map;
	}
}
