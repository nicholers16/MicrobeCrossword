package mod;

import javax.swing.JOptionPane;
import java.util.Random;

import viewcon.Controller;

public class Overseer {

	private Controller _cnt;
	private Maze _maze;
	private Player _ply;
	private Minotaur _min1;
	private Minotaur _min2;
	private Minotaur _min3;
	private String _askName;
	private String input;
	private String _mazelvl;

	public Overseer() {

		javax.swing.JOptionPane.showMessageDialog( null,  "The year is 9022 and turkeys have taken over the world. \n" +
						"You, Natanthony Rico are the last survivor and hope for humanity. \n" +
				"You must get to the end of the maze to acquire a can of beans without getting killed by turkeys. \n" +
				"You will pick up a sword that you can use to defend yourself, but it has a 50% chance of breaking everytime you use it. \n" +
				"Be careful for hidden traps, where you will be forced to take inventory of supplies before moving on. If you cannot do simple math, \n" +
				"YOU DIE..... \n");
		javax.swing.JOptionPane.showMessageDialog( null, "Turkeys in this maze are represented by the symbol 'Ƃ'. \n" +
				"Players are represented by the symbol 'Ƥ'.\n" +
				"Walls are 'x', and paths are ' '\n"
				+"Good Luck! \n");
		_askName = JOptionPane.showInputDialog( "Enter player name. Type Rico to see traps" );
		_mazelvl = JOptionPane.showInputDialog("What level do you want to play? Easy, Medium, or Hard?");
		_maze = new Maze(_mazelvl);
		_ply = new Player(_maze.getStart());
		_min1 = new Minotaur(_maze.getSpawn1());
		_min2 = new Minotaur(_maze.getSpawn2());
		_min3 = new Minotaur(_maze.getSpawn3());
		//story, ask name, then ask level
		if (_askName.equalsIgnoreCase("Rico"))
		{
			_cnt = new Controller(_ply, _maze, _min1, _min2, _min3,  _askName," Use WASD to move in the maze. ");

		}
		else
		{
			_cnt = new Controller(_ply, _maze, _min1, _min2, _min3, _askName ," Use WASD to move in the maze");
		}
		update();

		//controller asks for name first, but maze is already created. if msg.equals rico, print maze with traps?
	}
	
	private void update() {
		int pRow = _ply.getLoc().getRow();
		int pCol = _ply.getLoc().getCol();
		int m1Row = _min1.getLoc().getRow();

		int m1Col = _min1.getLoc().getCol();
		int m2Row = _min2.getLoc().getRow();
		int m2Col = _min2.getLoc().getCol();
		int m3Row = _min3.getLoc().getRow();
		int m3Col = _min3.getLoc().getCol();
		int endRow = _maze.getEnd().getRow();
		int endCol = _maze.getEnd().getCol();

		int sRow = _maze.getSword().getRow();
		int sCol = _maze.getSword().getCol();

		
		while(!(pRow == endRow && pCol == endCol) &&
				!(_ply.isDead())) {
			movePlayer(_cnt.move());
			moveMinotaur1();
			moveMinotaur2();
			moveMinotaur3();
			pRow = _ply.getLoc().getRow();
			pCol = _ply.getLoc().getCol();
			m1Row = _min1.getLoc().getRow();
			m1Col = _min1.getLoc().getCol();
			m2Row = _min2.getLoc().getRow();
			m2Col = _min2.getLoc().getCol();
			m3Row = _min3.getLoc().getRow();
			m3Row = _min3.getLoc().getRow();
			m3Col = _min3.getLoc().getCol();
			/*
			pVE(pRow, pCol, m1Row, m1Col);
			pVE(pRow, pCol, m2Row, m2Col);
			pVE(pRow, pCol, m3Row, m3Col);

			 */
			pickUpSword(pRow, pCol, sRow, sCol);
			killMino( pRow,  pCol,  m1Row,  m1Col,  m2Row,  m2Col,  m3Row,  m3Col);
			activateTrap();

		}
		if(!_ply.isDead()) {
			_cnt.victory();
		}
		else {
			_cnt.defeat();
		}
	}

	private void pickUpSword (int pRow, int pCol, int sRow, int sCol){
		if (pRow == sRow && pCol == sCol)
		{
			_ply.pickUpSword();
			_maze.removeSword();

		}
	}


	private void activateTrap(){
		int t1Row = _maze.getTrap1().getRow();
		int t2Row = _maze.getTrap2().getRow();
		int t3Row = _maze.getTrap3().getRow();
		int t1Col = _maze.getTrap1().getCol();
		int t2Col = _maze.getTrap2().getCol();
		int t3Col = _maze.getTrap3().getCol();
		int pRow = _ply.getLoc().getRow();
		int pCol = _ply.getLoc().getCol();
		if (t1Row==pRow && t1Col==pCol){
			if (!_ply.isDead())
			{
				if (askQuestion()==true){
					_ply.kill();
				}
			}
			if (t2Row==pRow && t2Col==pCol){
				if (askQuestion()==true){
					_ply.kill();
				}

			}
			if (t3Row==pRow && t3Col==pCol){
				if (askQuestion()==true){
					_ply.kill();
				}
			}
			}
	}

	private boolean askQuestion ()
	{
		String [] question = new String [] {"You have 10 bandaids. You get cut and use one. How many are left?",
				" 1 flashlight needs 2 batteries. How many batteries do 4 flashlights need? Integer only.",
				"90% of a 7 billion person population were killed by turkeys in 10 years. How many people survived? Integer only.",
				"Your position is represented by the function s(t) = 5x^2. What is your velocity when t = 2? Integer only.",
				"If you have a bag of 10 total apples and oranges, and 5 of them are apples, how many are oranges? Integer only.",
				"You are vegetarian, and kill a turkey. Can you eat it, 'yes' or 'no'?",
				"Turkeys, like ostriches are considered flightless. Are penguins flightless birds, 'yes' or 'no'?",
				"1 knife needs 3 turkey claws. How many claws do 2 knives need? Integer only.",
				"Can you figure this out? \n " +
						"Is computer science not useful in a world overrun by turkeys? Hint: the incorrect answer is not 'yes'"
		};
		String [] answer = new String [] {"9","8", "700000000", "20", "5", "no", "yes","6", "yes" };
		Random randomNum = new Random();
		int x = randomNum.nextInt(answer.length);
		String s = JOptionPane.showInputDialog(question[x]);
		if (s.equalsIgnoreCase(answer[x]))
		{
			return false;
		}
		else
		{
			return true;
		}



	}

	private void killMino (int pRow, int pCol, int m1Row, int m1Col, int m2Row, int m2Col, int m3Row, int m3Col){
		if ((pCol == m1Col) && (pRow == m1Row) && !_min1.isDead())

		{
			//if minotaur is next to player, use sword option
			input = JOptionPane.showInputDialog ( "Turkey at (" + pRow+ ", "+ pCol + ") "+ "Use sword? Type 'yes' to use. Remember, there's a 50% chance it'll break :( \n" );
			if (input.equalsIgnoreCase("yes"))
			{
				if (breakSword())
				{
					//sword 51-101 does break, breakSword == true
					javax.swing.JOptionPane.showMessageDialog( null,"Oh no! Sword broke. You're dead! \n" );
					_ply.kill();
				}
				else
				{
					javax.swing.JOptionPane.showMessageDialog( null,"Turkey Dead");
					_min1.kill();
				}
			}

		}
		else if ((pCol == m2Col) && (pRow == m2Row) && !_min2.isDead())

		{
			//if minotaur is next to player, use sword option
			input = JOptionPane.showInputDialog ( "Use sword? Type 'yes' to use. Remember, there's a 50% chance it'll break :( \n" );
			if (input.equalsIgnoreCase("yes"))
			{
				if (breakSword())
				{
					//sword 51-101 does break, breakSword == true
					javax.swing.JOptionPane.showMessageDialog( null,"Oh no! Sword broke. You're dead! \n" );
					//how do i set the hasSword equal to false?
					_ply.kill();
				}
				else
				{
					javax.swing.JOptionPane.showMessageDialog( null,"Turkey Dead");
					_min2.kill();
				}
			}

		}
		else if ((pCol == m3Col) && (pRow == m3Row) && !_min3.isDead())

		{
			//if minotaur is next to player, use sword option
			input = JOptionPane.showInputDialog ( "Use sword? Type 'yes' to use. Remember, there's a 50% chance it'll break :( \n" );
			if (input.equalsIgnoreCase("yes"))
			{
				if (breakSword())
				{
					//sword 51-101 does break, breakSword == true
					javax.swing.JOptionPane.showMessageDialog( null,"Oh no! Sword broke. You're dead! \n" );
					//how do i set the hasSword equal to false?
					_ply.kill();
				}
				else
				{
					javax.swing.JOptionPane.showMessageDialog( null,"Turkey Dead X(");
					_min3.kill();
				}
			}

		}
	}

	
	private boolean breakSword() {
		Random randomNum = new Random();
		int x = randomNum.nextInt(2);
		if (x == 0){
			return true;
		}
		else{
			return false;
		}
	}
	
	private void movePlayer(Direction d) {

		if(d == Direction.UP) 
			_ply.moveUp();
		
		else if(d == Direction.DOWN) 
			_ply.moveDown();
		
		else if(d == Direction.LEFT) 
			_ply.moveLeft();
		
		else 
			_ply.moveRight();
	}
	
	private void moveMinotaur1() {
		int _minRow = _min1.getLoc().getRow();
		int _minCol = _min1.getLoc().getCol();
		boolean[][] map = _maze.getMap().getArr();
		
		int rowDist = _min1.getLoc().getRow() - _ply.getLoc().getRow();
		int colDist = _min1.getLoc().getCol() - _ply.getLoc().getCol();
		
		if (!_min1.isDead())
		{
			if(rowDist > 0){ // Min Row > Ply Row
				if(map[_minRow - 1][_minCol]){
					_min1.moveUp();
				}
				else{
					if(colDist > 0 && map[_minRow][_minCol - 1]){ // Move Left
						_min1.moveLeft();
					}
					else if(colDist < 0 && map[_minRow][_minCol + 1]){
						_min1.moveRight();
					}
				}
			}
			else if(rowDist < 0){ // Min Row < Ply Row
				if(map[_minRow + 1][_minCol]){
					_min1.moveDown();
				}
				else{
					if(colDist > 0 && !map[_minRow][_minCol - 1]){
						_min1.moveLeft();
					}
					else if(colDist < 0 && map[_minRow][_minCol + 1]){
						_min1.moveRight();
					}
				}
			}
			else {
				if(colDist > 0 && map[_minRow][_minCol - 1]){
					_min1.moveLeft();
				}
				else if(colDist < 0 && map[_minRow][_minCol + 1]){
					_min1.moveRight();
				}

			}
		}
	}
	private void moveMinotaur2() {
		int _minRow = _min2.getLoc().getRow();
		int _minCol = _min2.getLoc().getCol();
		boolean[][] map = _maze.getMap().getArr();

		int rowDist = _min2.getLoc().getRow() - _ply.getLoc().getRow();
		int colDist = _min2.getLoc().getCol() - _ply.getLoc().getCol();

		if (!_min2.isDead())
		{
			if(rowDist > 0){ // Min Row > Ply Row
				if(map[_minRow - 1][_minCol]){
					_min2.moveUp();
				}
				else{
					if(colDist > 0 && map[_minRow][_minCol - 1]){ // Move Left
						_min2.moveLeft();
					}
					else if(colDist < 0 && map[_minRow][_minCol + 1]){
						_min2.moveRight();
					}
				}
			}
			else if(rowDist < 0){ // Min Row < Ply Row
				if(map[_minRow + 1][_minCol]){
					_min2.moveDown();
				}
				else{
					if(colDist > 0 && !map[_minRow][_minCol - 1]){
						_min2.moveLeft();
					}
					else if(colDist < 0 && map[_minRow][_minCol + 1]){
						_min2.moveRight();
					}
				}
			}
			else {
				if(colDist > 0 && map[_minRow][_minCol - 1]){
					_min2.moveLeft();
				}
				else if(colDist < 0 && map[_minRow][_minCol + 1]){
					_min2.moveRight();
				}

			}
		}
	}
	private void moveMinotaur3() {
		int _minRow = _min3.getLoc().getRow();
		int _minCol = _min3.getLoc().getCol();
		boolean[][] map = _maze.getMap().getArr();

		int rowDist = _min3.getLoc().getRow() - _ply.getLoc().getRow();
		int colDist = _min3.getLoc().getCol() - _ply.getLoc().getCol();

		if (!_min3.isDead())
		{
			if(rowDist > 0){ // Min Row > Ply Row
				if(map[_minRow - 1][_minCol]){
					_min3.moveUp();
				}
				else{
					if(colDist > 0 && map[_minRow][_minCol - 1]){ // Move Left
						_min3.moveLeft();
					}
					else if(colDist < 0 && map[_minRow][_minCol + 1]){
						_min3.moveRight();
					}
				}
			}
			else if(rowDist < 0){ // Min Row < Ply Row
				if(map[_minRow + 1][_minCol]){
					_min3.moveDown();
				}
				else{
					if(colDist > 0 && !map[_minRow][_minCol - 1]){
						_min3.moveLeft();
					}
					else if(colDist < 0 && map[_minRow][_minCol + 1]){
						_min3.moveRight();
					}
				}
			}
			else {
				if(colDist > 0 && map[_minRow][_minCol - 1]){
					_min3.moveLeft();
				}
				else if(colDist < 0 && map[_minRow][_minCol + 1]){
					_min3.moveRight();
				}

			}
		}
	}
	
	
	
	
	
	
}
