package mod;

public class Maze {

	private Map _map;
	private Location _start, _end, _trap1,_trap2, _trap3, _spawn1, _spawn2, _spawn3, _sword;

	public Map getMap() {
		return _map;
	}

	public Location getStart() {
		return _start;
	}

	public Location getEnd() {
		return _end;
	}

	public Location getTrap1() {
		return _trap1;
	}
	public Location getTrap2() {
		return _trap2;
	}
	public Location getTrap3() {
		return _trap3;
	}

	public Location getSpawn1() {return _spawn1;}
	public Location getSpawn2() {
		return _spawn2;
	}
	public Location getSpawn3() {
		return _spawn3;
	}

	public Location getSword () { return _sword;}
	public void removeSword () { _sword.remove();}


	//ask player input 0, 1 or 2 for their leve
	public Maze(String s) {
		if (s.equalsIgnoreCase("Easy")) {
			_map = Map.Easy;
			_start = new Location(0, 0);
			_end = new Location(17, 14);
			_trap1 = new Location (2,0);
			_trap2 = new Location (8,12);
			_trap3 = new Location (10,12);
			_spawn1 = new Location (10,1);
			_spawn2 = new Location (8,4);
			_spawn3 = new Location (11,12);
			_sword = new Location (1,0);
		}
		if (s.equalsIgnoreCase("Medium"))  {
			_map = Map.Medium;
			_start = new Location(0, 6);
			_end = new Location(17, 7);
			_trap1 = new Location (3,5);
			_trap2 = new Location (4,1);
			_trap3 = new Location (6,2);
			_spawn1 = new Location (4,1);
			_spawn2 = new Location (11,12);
			_spawn3 = new Location (16,11);
			_sword = new Location (1,6);
		}
		if (s.equalsIgnoreCase("Hard"))  {
			_map = Map.Hard;
			_start = new Location(0, 0);
			_end = new Location(17, 1);
			_trap1 = new Location (2,3);
			_trap2 = new Location (14,4);
			_trap3 = new Location (10,10);
			_spawn1 = new Location (14,7);
			_spawn2 = new Location (6,9);
			_spawn3 = new Location (10,13);
			_sword = new Location (1,0);
		}
	}

}
