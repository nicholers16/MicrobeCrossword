package viewcon;

import javax.swing.JOptionPane;

import mod.Direction;
import mod.Maze;
import mod.Minotaur;
import mod.Player;

public class Controller {
	
	private Player _ply;
	private Minotaur _minO;
	private Minotaur _minT;
	private Minotaur _minTh;
	private Maze _map;
	private String _name;



	private String _msg;

	//do i have to ad 3 trap parameters to controller constructor and draw map method?
	public Controller(Player ply, Maze map, Minotaur min1, Minotaur min2, Minotaur min3, String name, String m) {
		_ply = ply;
		_map = map;
		_minO = min1;
		_minT = min2;
		_minTh = min3;
		_name = name;
		_msg = m;
	}
	
	public Direction move() {
		String s = JOptionPane.showInputDialog(drawMap() + "\n" + _msg + "Player has sword: " + _ply.checkSword());
		Direction d = convertInput(s);
		while(!isValid(d)) {
			JOptionPane.showMessageDialog(null, "not a valid move!");
			s = JOptionPane.showInputDialog(drawMap() + "\n" + _msg + "\n");
			d = convertInput(s);
		}
		return d;
	}
	
	private boolean isValid(Direction d) {
		boolean[][] map = _map.getMap().getArr();
		int row = _ply.getLoc().getRow();
		int col = _ply.getLoc().getCol();
		
		if(d == Direction.UP) {
			if(row == 0)
				return false;
			row--;
			return map[row][col];
		}
		else if(d == Direction.DOWN) {
			if(row == map.length - 1)
				return false;
			row++;
			return map[row][col];
		}
		else if(d == Direction.LEFT) {
			if(col == 0)
				return false;
			col--;
			return map[row][col];
		}
		else {
			if(col == map[row].length - 1)
				return false;
			col++;
			return map[row][col];
		}
	}
	
	private Direction convertInput(String s) {
		if(s.equalsIgnoreCase("w")) {
			return Direction.UP;			
		}
		else if(s.equalsIgnoreCase("a")) {
			return Direction.LEFT;
		}
		else if(s.equalsIgnoreCase("s")) {
			return Direction.DOWN;
		}
		else if(s.equalsIgnoreCase("d")) {
			return Direction.RIGHT;
		}
		else {
			return Direction.UP;
		}
	}
	
	public void victory() {
		JOptionPane.showMessageDialog(null, drawMap() + "\n" + "You got the can of beans! Congratulations on surviving...this time" + "\n");
	}
	
	public void defeat() {
		JOptionPane.showMessageDialog(null, drawMap() + "\n" + "You got KILLED by a TURKEY! Weak." + "\n");
	}

	
	private String drawMap() {
		String MAP = "";
		String ply = "Ƥ";
		String wall = "x";
		String path = "  ";
		String space = "   ";
		String min = "Ƃ";
		String end = "E";
		String trap = "T";
		String sword = "S";

		int pRow = _ply.getLoc().getRow();
		int pCol = _ply.getLoc().getCol();
		int m1Row = _map.getSpawn1().getRow();
		int m1Col = _map.getSpawn1().getCol();
		int m2Row = _map.getSpawn2().getRow();
		int m2Col = _map.getSpawn2().getCol();
		int m3Row = _map.getSpawn3().getRow();
		int m3Col = _map.getSpawn3().getCol();

		int t1Row = _map.getTrap1().getRow();
		int t1Col = _map.getTrap1().getCol();
		int t2Row = _map.getTrap2().getRow();
		int t2Col = _map.getTrap2().getCol();
		int t3Row = _map.getTrap3().getRow();
		int t3Col = _map.getTrap3().getCol();

		int eRow = _map.getEnd().getRow();
		int eCol = _map.getEnd().getCol();

		int sRow = _map.getSword().getRow();
		int sCol = _map.getSword().getCol();
		
		boolean[][] map = _map.getMap().getArr();

		if (_name.equalsIgnoreCase("Rico"))
		{
			for(int r = 0; r < map.length; r++) {
				for(int c = 0; c < map[r].length; c++) {
					if(r == m1Row && c == m1Col && !_minO.isDead()) {
						MAP += min + space;
					}
					else if(r == m2Row && c == m2Col && !_minT.isDead()) {
						MAP += min + space;
					}
					else if(r == m3Row && c == m3Col && !_minTh.isDead()) {
						MAP += min + space;
					}
					else if(r == pRow && c == pCol) {
						MAP += ply + space;
					}
					else if(r == eRow && c == eCol) {
						MAP += end + space;
					}
					else if ( r == sRow && c == sCol)
					{
						MAP += sword + space;
					}
					else if (r == t1Row && c == t1Col)
					{
						MAP += trap +space;
					}
					else if (r == t2Row && c == t2Col)
					{
						MAP += trap +space;
					}
					else if (r == t2Row && c == t2Col)
					{
						MAP += trap +space;
					}
					else if (r == t3Row && c == t3Col)
					{
						MAP += trap +space;
					}
					else if(map[r][c]) {
						MAP += path + space;
					}
					else {
						MAP += wall + space;
					}
				}
				MAP += "\n";
			}
		}
		else
		{
			for(int r = 0; r < map.length; r++) {
				for(int c = 0; c < map[r].length; c++) {
					if(r == m1Row && c == m1Col && !_minO.isDead()) {
						MAP += min + space;
					}
					else if(r == m2Row && c == m2Col && !_minT.isDead() ) {
						MAP += min + space;
					}
					else if(r == m3Row && c == m3Col && !_minTh.isDead()) {
						MAP += min + space;
					}
					else if(r == pRow && c == pCol) {
						MAP += ply + space;
					}
					else if(r == eRow && c == eCol) {
						MAP += end + space;
					}
					else if ( r == sRow && c == sCol)
					{
						MAP += sword + space;
					}
					else if(map[r][c]) {
						MAP += path + space;
					}
					else {
						MAP += wall + space;
					}
				}
				MAP += "\n";

			}
		}

		
		return MAP;
	}
	
	
}
